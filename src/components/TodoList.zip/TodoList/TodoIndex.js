import React, { Component } from 'react'
import ShowJob from './ShowJob'
import AddJob from './AddJob'

export default class TodoIndex extends Component {
    render() {
        return (
            <div className="container">
                <div className="row">

                <AddJob/>
                <ShowJob/>
                </div>

                
            </div>


        )
    }
}
