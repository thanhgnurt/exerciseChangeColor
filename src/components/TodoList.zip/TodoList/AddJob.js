import React, { Component } from 'react'

export default class AddJob extends Component {
    render() {
        return (
            
                <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4 card">
                    <div className="card-body btn btn-info">Secondary card</div>
                    <form>
                        <div className="form-group">
                            <label className="text-dark mt-3">Name :</label>
                            <input
                                type="email"
                                className="form-control"
                                id="exampleInputEmail1"
                                aria-describedby="emailHelp"
                                placeholder="Enter email"
                            />
                        </div>
                        <label className="text-dark">Status :</label>
                        <div className="input-group mb-3">
                            <select className="custom-select" id="inputGroupSelect02">
                                <option value={1}>Hide</option>
                                <option value={2}>Show up</option>
                            </select>
                        </div>
                        <div className="text-left">
                            <button type="submit" className="btn btn-warning mb-3 mr-2 text-center px-4">
                                {" "}
          Save{" "}
                            </button>
                            <button type="button" className="btn btn-danger mb-3 text-center px-4">
                                {" "}
          Cancel{" "}
                            </button>
                        </div>
                    </form>
                </div>
            

        )
    }
}
