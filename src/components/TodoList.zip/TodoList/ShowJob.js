import React, { Component } from 'react'

export default class ShowJob extends Component {
    render() {
        return (
            <div className="col-8">
                <div className="container">
                    <button type="button" className="btn btn-info">
                        <i className="fa fa-plus" /> Add Staff
    </button>
                </div>
                <nav className="navbar navbar-light bg-light container">
                    <form className="form-inline">
                        <input
                            className="form-control mr-sm-2"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                        />
                        <button className="btn btn-outline-success my-2 my-sm-0" type="submit">
                            Search
      </button>
                        <div className="nav-item dropdown ml-5">
                            <a
                                className="nav-link dropdown-toggle"
                                href="#"
                                id="navbarDropdown"
                                role="button"
                                data-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                            >
                                Sort
        </a>
                            <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a className="dropdown-item" href="#">
                                    <i className="fa fa-sort-alpha-asc" />
                                </a>
                                <a className="dropdown-item" href="#">
                                    <i className="fas fa-sort-alpha-down-alt" />
                                </a>
                                <div className="dropdown-divider" />
                                <a className="dropdown-item" href="#">
                                    Active
          </a>
                                <a className="dropdown-item" href="#">
                                    Disable
          </a>
                            </div>
                        </div>
                    </form>
                </nav>
                <table className="container table table-bordered table-secondary text-center">
                    <thead>
                        <tr>
                            <th scope="col">Serial</th>
                            <th scope="col">Name</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row" />
                            <td>
                                <input
                                    className="form-control mr-sm-2"
                                    type="search"
                                    placeholder="Search"
                                    aria-label="Search"
                                />
                            </td>
                            <td>
                                <div className="input-group mb-3">
                                    <select className="custom-select" id="inputGroupSelect02">
                                        <option selected>All...</option>
                                        <option value={1}>Hide</option>
                                        <option value={2}>Show up</option>
                                    </select>
                                    <div className="input-group-append">
                                        <label className="input-group-text" htmlFor="inputGroupSelect02">
                                            Options
              </label>
                                    </div>
                                </div>
                            </td>
                            <td />
                        </tr>
                        {/* <tr>
          <th scope="row">1</th>
          <td>Jacob</td>
          <td>Thornton</td>
          <td>@fat</td>
        </tr> */}
                    </tbody>
                </table>
            </div>

        )
    }
}
